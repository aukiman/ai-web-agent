from utils import human_pause

async def ensure_logged_in(page, site):
    # Stub: integrate cookie/session load if needed.
    # e.g., context.add_cookies(...) after reading site['login']['cookie_path']
    pass

async def like_post(page, post):
    if not post.get("url"): return
    await page.goto(post["url"], wait_until="domcontentloaded")
    await page.wait_for_selector("button:has-text('Like')", timeout=5000)
    await page.click("button:has-text('Like')")
    await human_pause({"limits":{"min_delay_sec":1,"max_delay_sec":3}})

async def reply_to_post(page, post, text):
    if not post.get("url"): return
    await page.goto(post["url"], wait_until="domcontentloaded")
    await page.wait_for_selector("textarea, [contenteditable='true']", timeout=5000)
    if await page.locator("textarea").count() > 0:
        await page.fill("textarea", text)
    else:
        el = page.locator("[contenteditable='true']").first
        await el.click()
        await el.type(text, delay=20)
    await human_pause({"limits":{"min_delay_sec":1,"max_delay_sec":2}})
    for label in ["Reply", "Post", "Send"]:
        if await page.locator(f"button:has-text('{label}')").count() > 0:
            await page.click(f"button:has-text('{label}')")
            break
