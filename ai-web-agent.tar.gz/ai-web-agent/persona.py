import json

def build_prompt(cfg: dict, post: dict) -> str:
    style = {
      "voice": "casual, witty, Aussie spelling, no sales talk",
      "length": "1–2 sentences",
      "avoid": cfg["safety"]["no_go_keywords"],
      "add": ["be kind", "no hashtags unless relevant", "no emojis unless context fits"]
    }
    return f"""
You write short, human replies to social posts.
Rules:
- Acknowledge the author's point
- Add one useful or funny thought
- Keep it natural and under {cfg['safety']['max_reply_length']} characters
- Avoid: {', '.join(cfg['safety']['no_go_keywords'])}
Post text: {post.get('text','')}
Author: {post.get('author','unknown')}
Voice rules: {json.dumps(style)}
ONLY return the reply text.
"""
