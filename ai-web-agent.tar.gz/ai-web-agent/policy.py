class PolicyGuard:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.no_go = set(k.lower() for k in cfg["safety"].get("no_go_keywords", []))
        self.daily_cap = cfg["limits"]["daily_actions_per_site"]

    def content_score(self, post: dict) -> float:
        text = (post.get("text") or "").lower()
        if any(k in text for k in self.no_go):
            return 0.0
        # trivial scorer: length & simple signals
        base = min(len(text) / 140.0, 1.0)
        return 0.5 + 0.5 * base

    def moderate(self, draft: str, post: dict) -> str:
        mx = self.cfg["safety"]["max_reply_length"]
        draft = draft.strip()[:mx]
        for k in self.no_go:
            draft = draft.replace(k, "")
        return draft

    def can_act(self) -> bool:
        # You could track actions/day per site; stub returns True
        return True
