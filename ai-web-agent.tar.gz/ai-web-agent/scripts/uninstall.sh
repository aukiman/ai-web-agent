#!/usr/bin/env bash
set -euo pipefail
APP_NAME="ai-web-agent"
APP_USER="aiagent"
SERVICE_NAME="aiwebagent"
APP_DIR="/opt/${APP_NAME}"

echo "[*] Stopping systemd units..."
systemctl stop "${SERVICE_NAME}.timer" || true
systemctl stop "${SERVICE_NAME}.service" || true
systemctl disable "${SERVICE_NAME}.timer" || true
systemctl disable "${SERVICE_NAME}.service" || true
rm -f "/etc/systemd/system/${SERVICE_NAME}.service" "/etc/systemd/system/${SERVICE_NAME}.timer"
systemctl daemon-reload

echo "[*] Removing ${APP_DIR}..."
rm -rf "${APP_DIR}"

echo "[*] Removing user ${APP_USER} (home already removed)..."
userdel "${APP_USER}" || true

echo "[*] Uninstalled."
