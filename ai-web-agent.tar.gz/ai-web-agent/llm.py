import os
from dotenv import load_dotenv
load_dotenv()

import json, urllib.request

BASE = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
KEY  = os.getenv("OPENAI_API_KEY", "")
MODEL= os.getenv("OPENAI_MODEL", "gpt-4o-mini")

def complete(prompt: str, max_tokens: int = 180) -> str:
    url = f"{BASE}/chat/completions"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {KEY}",
    }
    body = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": "You are a concise, friendly assistant."},
            {"role": "user", "content": prompt},
        ],
        "max_tokens": max_tokens,
        "temperature": 0.7,
    }
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=60) as r:
        data = json.loads(r.read())
    return data["choices"][0]["message"]["content"].strip()
