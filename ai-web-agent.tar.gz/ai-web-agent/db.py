import sqlite3, json, time
from contextlib import contextmanager
from typing import Any

class DB:
    def __init__(self, path: str):
        self.path = path
        self._init()

    @contextmanager
    def _conn(self):
        con = sqlite3.connect(self.path)
        try:
            yield con
        finally:
            con.close()

    def _init(self):
        with self._conn() as con:
            con.execute("""CREATE TABLE IF NOT EXISTS posts(
              id TEXT PRIMARY KEY,
              site_id TEXT,
              external_id TEXT,
              author TEXT,
              text TEXT,
              ts TEXT,
              url TEXT,
              metrics_json TEXT,
              seen_at INTEGER,
              acted INTEGER DEFAULT 0
            )""")
            con.execute("""CREATE TABLE IF NOT EXISTS actions(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              post_id TEXT,
              type TEXT,
              status TEXT,
              detail_json TEXT,
              created_at INTEGER
            )""")
            con.commit()

    def seen(self, post_id: str) -> bool:
        with self._conn() as con:
            cur = con.execute("SELECT 1 FROM posts WHERE id=? LIMIT 1", (post_id,))
            return cur.fetchone() is not None

    def save_post(self, post_id, site_id, post: dict, score: float):
        with self._conn() as con:
            con.execute("""INSERT OR IGNORE INTO posts
              (id, site_id, external_id, author, text, ts, url, metrics_json, seen_at, acted)
              VALUES (?,?,?,?,?,?,?,?,?,0)""",                      (post_id, site_id, post.get("external_id",""), post.get("author",""), post.get("text",""),
               post.get("ts",""), post.get("url",""), json.dumps(post.get("metrics",{})), int(time.time())))
            con.commit()

    def enqueue_action(self, post_id, typ, detail: dict):
        with self._conn() as con:
            con.execute("""INSERT INTO actions (post_id, type, status, detail_json, created_at)
                           VALUES (?, ?, 'queued', ?, ?)""",                                   (post_id, typ, json.dumps(detail), int(time.time())))
            con.commit()

    def mark_acted(self, post_id):
        with self._conn() as con:
            con.execute("UPDATE posts SET acted=1 WHERE id=?", (post_id,))
            con.commit()
