import os, asyncio, argparse, json
from dotenv import load_dotenv
load_dotenv()

from playwright.async_api import async_playwright
from utils import load_yaml, human_pause, within_quiet_hours, hash_post
from db import DB
from policy import PolicyGuard
from persona import build_prompt
from llm import complete
from extractors import extract_posts
from actions import like_post, reply_to_post, ensure_logged_in

async def run_once():
    cfg = load_yaml("config.yaml")
    db = DB("agent.db")
    guard = PolicyGuard(cfg)

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context()
        page = await context.new_page()

        for feed in cfg.get("feeds", []):
            if not feed.get("enabled"):
                continue
            site = next(s for s in cfg["sites"] if s["id"] == feed["site_id"])
            mode = cfg.get("mode","research")

            if site.get("login", {}).get("required"):
                await ensure_logged_in(page, site)

            await page.goto(feed["url"], wait_until="networkidle")
            await human_pause(cfg)

            posts = await extract_posts(page, site)
            for post in posts:
                post_id = hash_post(site["id"], post["external_id"])
                if db.seen(post_id):
                    continue

                score = guard.content_score(post)
                db.save_post(post_id, site["id"], post, score)

                if score < 0.7:
                    continue

                if mode in ("draft","engage"):
                    prompt = build_prompt(cfg, post)
                    draft = complete(prompt, max_tokens=180)
                    draft = guard.moderate(draft, post)

                    if mode == "draft":
                        db.enqueue_action(post_id, "reply_draft", {"draft": draft})
                    elif mode == "engage" and site.get("engagement_allowed", False) and guard.can_act():
                        if not within_quiet_hours(cfg):
                            try:
                                await like_post(page, post)
                            except Exception:
                                pass
                            await human_pause(cfg)
                            try:
                                await reply_to_post(page, post, draft)
                            except Exception:
                                pass
                            db.mark_acted(post_id)
                            await human_pause(cfg)

        await browser.close()

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--once", action="store_true", help="Run one pass and exit")
    args = ap.parse_args()

    if args.once:
        asyncio.run(run_once())
    else:
        asyncio.run(run_once())
