import os, random, asyncio, hashlib
from datetime import datetime, time as dtime
import yaml

def load_yaml(path):
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def now_local(tz: str | None = None):
    # System TZ is used; you can enhance with pytz/zoneinfo if needed
    return datetime.now()

async def human_pause(cfg):
    mn = cfg["limits"]["min_delay_sec"]
    mx = cfg["limits"]["max_delay_sec"]
    await asyncio.sleep(random.uniform(mn, mx))

def within_quiet_hours(cfg):
    q = cfg["limits"].get("quiet_hours", {})
    if not q: return False
    now = now_local()
    start = dtime.fromisoformat(q["start"])
    end   = dtime.fromisoformat(q["end"])
    if start <= end:
        return start <= now.time() <= end
    # spans midnight
    return now.time() >= start or now.time() <= end

def hash_post(site_id, external_id):
    return hashlib.sha256(f"{site_id}:{external_id}".encode()).hexdigest()
