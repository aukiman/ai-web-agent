from datetime import datetime

async def extract_posts(page, site):
    # Example extractor for a generic microblog-like page.
    # Adjust CSS selectors for each site and add more extractors as needed.
    await page.wait_for_selector("article")
    cards = await page.query_selector_all("article")
    results = []
    for c in cards:
        text = (await c.inner_text()).strip()
        a = await c.query_selector("a")
        href = await a.get_attribute("href") if a else None
        ext_id = (href or f"{hash(text)}").split("/")[-1]
        results.append({
            "external_id": str(ext_id),
            "author": "unknown",
            "text": text,
            "url": href or "",
            "ts": datetime.utcnow().isoformat(),
            "metrics": {}
        })
    return results
